export const meta = {
  name: 'skillpath-assignment-review',
  description: 'Review Skillpath Framer assignment code across 4 dimensions, adversarially verify every finding',
  phases: [
    { title: 'Find', detail: '4 independent review dimensions' },
    { title: 'Verify', detail: 'one adversarial skeptic per finding' },
  ],
}

const CONTEXT = `
You are reviewing a junior-developer hiring assignment submission. Repo: /Users/ratnam/skillpath-project
Files: CourseGrid.tsx (the main graded component — a Framer React code component), Hero.tsx, Header.tsx, Footer.tsx, README.md, .gitignore.
The assignment brief is at "/Users/ratnam/Downloads/Assignment for the junior developer role.md" — READ IT FIRST, it defines the grading rubric.

Key rubric facts: flaky API (~1/3 requests fail on both endpoints), must handle loading/error/empty/working, currency logic (pricePaise is paise: 199900 paise = ₹1999, NOT ₹1,99,900; priceUsdCents is cents), exactly the states matter, 3/2/1 responsive columns, two property controls, no hardcoded data, GET only. Instant-fail list includes wrong price math and blank loading.

CRITICAL REVIEW STANDARD: The author explicitly said much of the code is INTENTIONALLY OPINIONATED (single-file component, currency-never-errors design, INR fallback, etc. — many choices carry written rationale in comments). Do NOT report taste, style preference, or "consider X" hedges. Report ONLY concrete, demonstrable defects: something that breaks, violates the brief, renders wrong, or is a real maintainability trap. Every claim must cite file + line and be checkable. If you are not certain, do not report it.
You may run commands: node -e for Intl/JS behavior checks, curl for the live API (https://syncsphere-hiv6.onrender.com/assignment/course-data and /assignment/country-code — both flaky by design, retry a few times).
`

const FINDINGS = {
  type: 'object',
  required: ['findings'],
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        required: ['file', 'line', 'title', 'severity', 'claim', 'evidence'],
        properties: {
          file: { type: 'string', description: 'filename e.g. CourseGrid.tsx' },
          line: { type: 'number', description: '1-indexed line the finding anchors to' },
          title: { type: 'string', description: 'short label, <=70 chars' },
          severity: { enum: ['blocker', 'should-fix', 'nit'], description: 'blocker = would cost rubric points or instant-fail; should-fix = real defect, minor consequence; nit = objectively true but tiny' },
          claim: { type: 'string', description: 'precise statement of the defect' },
          evidence: { type: 'string', description: 'how you verified it: exact code behavior, command output, spec quote' },
        },
      },
    },
  },
}

const VERDICT = {
  type: 'object',
  required: ['refuted', 'confidence', 'reasoning'],
  properties: {
    refuted: { type: 'boolean', description: 'true if the claim is wrong, overstated, or actually intended+harmless' },
    confidence: { enum: ['high', 'medium', 'low'] },
    reasoning: { type: 'string' },
    revised_claim: { type: 'string', description: 'if partially right, the corrected precise claim' },
  },
}

const DIMENSIONS = [
  {
    key: 'spec',
    prompt: `${CONTEXT}
Dimension: SPEC COMPLIANCE. Walk the assignment brief requirement by requirement (hero, courses section fields, currency logic, four states, mixed country-fails/courses-works case, GET only, two property controls, 3/2/1 responsive, no hardcoded data, stretch goals, the "what to share" checklist, the "straight no" list, note <= 200 words). For each, verify in the code whether it is met. Report ONLY requirements that are unmet, ambiguously met, or at risk — including submission-document problems in README.md (e.g. placeholders that must be filled, broken markdown). Verify the price math requirement by actually computing what the code renders (node -e with Intl if needed). Return findings.`,
  },
  {
    key: 'correctness',
    prompt: `${CONTEXT}
Dimension: CORRECTNESS. Hunt real bugs in CourseGrid.tsx primarily (Hero/Header/Footer secondarily): async races, AbortController usage, retry logic, React StrictMode double-mount, state transitions between loading/error/empty/ready, the currency fallback path, duplicate/unstable React keys (e.g. key={label}, key={course.courseCode}), empty-string/whitespace edge cases (heading.split, accentWord, query.trim), sort-while-currency-unresolved behavior, validation gaps in isCourse/parseCountry, anything that can throw or render wrong. Actually trace each candidate to a concrete failing scenario — run node -e to confirm JS semantics (Intl.NumberFormat outputs for the exact price values 199900 paise and 3999 cents, "".split(" "), etc.). Report only findings with a demonstrable failure scenario.`,
  },
  {
    key: 'ui',
    prompt: `${CONTEXT}
Dimension: CSS / RESPONSIVE / ACCESSIBILITY. Check: the auto-fill grid math actually yields 3 columns at ~1210px desktop, 2 at ~768px tablet, 1 at ~375px mobile and never breaks between (compute track counts from minmax(min(320px,100%),1fr) with 24px gap and 24px side padding); CSS specificity conflicts inside the <style> blocks (pay close attention to broad selectors like ".sp-root :focus-visible" and ".sp-hero :focus-visible" that set properties such as border-radius — compute specificity vs the element rules they may override and state the exact visual consequence); line-clamp + min-height consistency; container queries requiring container-type (verify each file that uses @container declares container-type); the mobile header nav being display:none with no alternative; aria attributes; prefers-reduced-motion blocks; @import font inside <style> duplicated across 4 components. Only report things with a concrete, observable wrong outcome.`,
  },
  {
    key: 'quality',
    prompt: `${CONTEXT}
Dimension: SOLID / DRY / READABILITY — but held to the "no vague advice" bar. The single-file CourseGrid choice is documented and intentional; do not fight it. Look for: real duplication that will drift (design tokens T + FONT + focus-visible + reduced-motion blocks copy-pasted across 4 files — assess whether Framer actually supports shared code modules between code files, check framer.com/developers docs via curl/WebFetch if needed, and whether the stated paste-drift rationale in CourseGrid.tsx lines 4-9 holds up); dead or misleading code (unused Course fields in the interface vs what isCourse validates vs what renders — mangoId is absent from the interface, mainCategory/shortCourse/refundable are in the interface but not validated by isCourse: is that an actual gap given refundable is rendered and search uses mainCategory/shortCourse?); naming/comment accuracy (comments that claim things the code does not do); anything a hiring reviewer would flag in the "is the code readable: 15 points" bucket as an objective defect rather than taste. Report only concrete items.`,
  },
]

phase('Find')
const rounds = await parallel(
  DIMENSIONS.map((d) => () =>
    agent(d.prompt, { label: `find:${d.key}`, phase: 'Find', schema: FINDINGS })
  )
)

// Barrier justified: dedup across ALL dimensions before paying for verification.
const raw = rounds.filter(Boolean).flatMap((r, i) =>
  r.findings.map((f) => ({ ...f, dimension: DIMENSIONS[i] ? DIMENSIONS[i].key : 'unknown' }))
)
const seen = new Set()
const deduped = []
for (const f of raw) {
  const k = `${f.file}:${f.line}:${f.title.toLowerCase().slice(0, 40)}`
  if (seen.has(k)) continue
  seen.add(k)
  deduped.push(f)
}
const rank = { blocker: 0, 'should-fix': 1, nit: 2 }
deduped.sort((a, b) => (rank[a.severity] ?? 3) - (rank[b.severity] ?? 3))

const CAP = 11
const toVerify = deduped.slice(0, CAP)
const dropped = deduped.slice(CAP)
if (dropped.length) log(`Capped verification at ${CAP}; ${dropped.length} lower-severity findings passed through unverified: ${dropped.map((f) => f.title).join(' | ')}`)
log(`${raw.length} raw findings, ${deduped.length} after dedup, verifying ${toVerify.length}`)

phase('Verify')
const verified = await parallel(
  toVerify.map((f) => () =>
    agent(
      `${CONTEXT}
You are an adversarial verifier. A reviewer claims the following defect in this submission. Your job is to REFUTE it if you possibly can. Read the actual file at the cited line and its surroundings, re-derive the behavior yourself, run node -e / curl to test semantics where applicable, and check the assignment brief. Refute if: the claim is factually wrong; the scenario cannot actually occur; the behavior is intended AND harmless per the brief; or the claim is too vague to act on (the author demanded zero vague advice). If the core is right but details are off, set refuted=false and give a revised_claim with the corrected precise statement. Default to refuted=true when uncertain.

CLAIM under review:
- File: ${f.file}, line ${f.line}
- Title: ${f.title}
- Severity claimed: ${f.severity}
- Claim: ${f.claim}
- Reviewer's evidence: ${f.evidence}`,
      { label: `verify:${f.title.slice(0, 40)}`, phase: 'Verify', schema: VERDICT, effort: 'high' }
    ).then((v) => ({ ...f, verdict: v }))
  )
)

const survived = verified.filter(Boolean).filter((f) => f.verdict && !f.verdict.refuted)
const refuted = verified.filter(Boolean).filter((f) => f.verdict && f.verdict.refuted)
return {
  confirmed: survived,
  refuted: refuted.map((f) => ({ title: f.title, file: f.file, line: f.line, why: f.verdict.reasoning })),
  unverified: dropped,
}